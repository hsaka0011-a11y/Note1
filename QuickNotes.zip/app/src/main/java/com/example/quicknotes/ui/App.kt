package com.example.quicknotes.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.quicknotes.data.Note
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuickNotesApp(vm: QuickNotesViewModel) {
    val notes by vm.notes.collectAsState()
    val query by vm.query.collectAsState()

    val filtered = remember(notes, query) {
        if (query.isBlank()) notes
        else notes.filter { it.title.contains(query, true) || it.body.contains(query, true) }
    }

    var editorState by remember { mutableStateOf<EditorState?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("QuickNotes") },
                actions = {
                    TextField(
                        value = query,
                        onValueChange = vm::setQuery,
                        singleLine = true,
                        placeholder = { Text("Search…") },
                        modifier = Modifier.width(200.dp)
                    )
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { editorState = EditorState.New }) { Text("+") }
        }
    ) { padding ->
        if (filtered.isEmpty()) {
            Box(Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No notes yet. Tap + to add one.")
            }
        } else {
            LazyColumn(Modifier.fillMaxSize().padding(padding)) {
                items(filtered, key = { it.id }) { note ->
                    NoteRow(note,
                        onClick = { editorState = EditorState.Edit(note) },
                        onDelete = { vm.delete(note) }
                    )
                }
            }
        }
    }

    when (val s = editorState) {
        EditorState.New -> NoteEditorDialog(
            title = "New note",
            onDismiss = { editorState = null },
            onSave = { title, body -> vm.add(title, body); editorState = null }
        )
        is EditorState.Edit -> NoteEditorDialog(
            title = "Edit note",
            initialTitle = s.note.title,
            initialBody = s.note.body,
            onDismiss = { editorState = null },
            onSave = { title, body -> vm.update(s.note, title, body); editorState = null }
        )
        null -> Unit
    }
}

@Composable
private fun NoteRow(note: Note, onClick: () -> Unit, onDelete: () -> Unit) {
    ListItem(
        headlineContent = { Text(note.title.ifBlank { "(untitled)" }) },
        supportingContent = {
            Text(
                note.body,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        },
        trailingContent = {
            Column(horizontalAlignment = Alignment.End) {
                Text(SimpleDateFormat("MMM d, yyyy h:mm a", Locale.getDefault()).format(Date(note.updatedAt)), style = MaterialTheme.typography.labelSmall)
                TextButton(onClick = onDelete) { Text("Delete") }
            }
        },
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 4.dp)
    )
    Divider()
}

private sealed interface EditorState { data object New : EditorState; data class Edit(val note: Note) : EditorState }

@Composable
private fun NoteEditorDialog(
    title: String,
    initialTitle: String = "",
    initialBody: String = "",
    onDismiss: () -> Unit,
    onSave: (String, String) -> Unit
) {
    var t by remember { mutableStateOf(initialTitle) }
    var b by remember { mutableStateOf(initialBody) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(Modifier.fillMaxWidth()) {
                OutlinedTextField(value = t, onValueChange = { t = it }, label = { Text("Title") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = b, onValueChange = { b = it }, label = { Text("Body") }, minLines = 6)
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(t.trim(), b.trim()) }) { Text("Save") }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
