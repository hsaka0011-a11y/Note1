package com.example.quicknotes.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.builtins.ListSerializer
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID

class NoteRepository(private val context: Context) {
    private val json = Json { prettyPrint = true; ignoreUnknownKeys = true }
    private val file: File by lazy { File(context.filesDir, "notes.json") }

    suspend fun load(): List<Note> = withContext(Dispatchers.IO) {
        if (!file.exists()) return@withContext emptyList()
        runCatching { json.decodeFromString(ListSerializer(Note.serializer()), file.readText()) }
            .getOrElse { emptyList() }
    }

    suspend fun save(notes: List<Note>) = withContext(Dispatchers.IO) {
        file.writeText(json.encodeToString(ListSerializer(Note.serializer()), notes))
    }

    fun newNote(title: String, body: String): Note {
        val now = System.currentTimeMillis()
        return Note(id = UUID.randomUUID().toString(), title, body, now, now)
    }
}
