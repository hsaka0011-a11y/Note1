package com.example.quicknotes.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.quicknotes.data.Note
import com.example.quicknotes.data.NoteRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class QuickNotesViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = NoteRepository(app)

    private val _notes = MutableStateFlow<List<Note>>(emptyList())
    val notes: StateFlow<List<Note>> = _notes.asStateFlow()

    private val _query = MutableStateFlow("")
    val query: StateFlow<String> = _query.asStateFlow()

    init {
        viewModelScope.launch { _notes.value = repo.load() }
    }

    fun setQuery(q: String) { _query.value = q }

    fun add(title: String, body: String) {
        viewModelScope.launch {
            _notes.update { (it + repo.newNote(title, body)).sortedByDescending(Note::updatedAt) }
            repo.save(_notes.value)
        }
    }

    fun update(note: Note, title: String, body: String) {
        viewModelScope.launch {
            val updated = note.copy(title = title, body = body, updatedAt = System.currentTimeMillis())
            _notes.update { list -> list.map { if (it.id == note.id) updated else it } }
            repo.save(_notes.value)
        }
    }

    fun delete(note: Note) {
        viewModelScope.launch {
            _notes.update { list -> list.filterNot { it.id == note.id } }
            repo.save(_notes.value)
        }
    }

    companion object {
        val Factory = androidx.lifecycle.viewmodel.initializer {
            val app = (this[androidx.lifecycle.ViewModelProvider.AndroidViewModelFactory.APPLICATION_KEY] as Application)
            QuickNotesViewModel(app)
        }
    }
}
